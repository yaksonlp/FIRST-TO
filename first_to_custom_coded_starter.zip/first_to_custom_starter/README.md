# FIRST TO — custom-coded starter

A Node/Express starter for an unreleased music store in Nigerian naira.

## Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Set `SESSION_SECRET` to a long random secret, `ADMIN_PASSWORD` to a unique strong password, and `PAYSTACK_SECRET_KEY` to your Paystack **test** secret key.
4. Run `npm install`
5. Run `npm start`
6. Open http://localhost:3000

Use a test key until you have completed test transactions. Set `PUBLIC_BASE_URL` to your public HTTPS domain when deployed.

## What is implemented
- Public song catalogue and preview-only audio route.
- Admin password sign-in and upload form for title, NGN price, release date, preview, full song.
- Server-side checkout initialization with price loaded from the database.
- Paystack NGN checkout channels including bank transfer.
- Paystack webhook HMAC signature validation, server-side transaction verification, amount/currency/reference matching, and idempotent purchase record.
- Full files stored outside the public web directory.

## IMPORTANT before taking real money
This is a starter, not a production-ready launch. Download delivery is deliberately disabled (HTTP 501) until you implement secure customer verification and short-lived signed links. Do not remove that safeguard or make full audio files public.

Before launch:
- Replace Express's default in-memory session store with a persistent store (e.g. Redis/Postgres) and set secure cookies behind HTTPS.
- Add login rate limiting, CSRF protection for session-authenticated mutations, admin password rotation, and preferably TOTP.
- Use private cloud object storage for audio; scan/validate uploads and enforce upload quotas.
- Add email verification or customer accounts + passwordless magic links; only then issue short-lived download links after a purchase lookup.
- Configure and test Paystack webhook URL `/api/paystack/webhook`; verify test-mode webhook delivery and retry behavior.
- Add order emails, receipts, refund handling, logging, backups, monitoring, privacy policy, terms, copyright/takedown process, and tax/accounting review.
- Check Paystack merchant eligibility and current payment channel availability for your account before launch.
- Ensure the production host supports Node.js, persistent database/storage, HTTPS, and environment secrets.

## Payment documentation
- Initialize/verify transactions: https://paystack.com/docs/api/transaction/
- Webhooks and HMAC signatures: https://paystack.com/docs/payments/webhooks/
- Verify payments before delivery: https://paystack.com/docs/payments/verify-payments/
- Payment channels: https://paystack.com/docs/payments/payment-channels/

Never expose the Paystack secret key in browser JavaScript or unlock a purchase from a screenshot or callback URL alone.
