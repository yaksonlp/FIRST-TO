import "dotenv/config";
import express from "express";
import helmet from "helmet";
import session from "express-session";
import multer from "multer";
import Database from "better-sqlite3";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const db = new Database(process.env.DB_PATH || "firstto.sqlite");
const PORT = Number(process.env.PORT || 3000);
const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || "./private_uploads");
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

if (!process.env.SESSION_SECRET || !process.env.PAYSTACK_SECRET_KEY || !process.env.ADMIN_PASSWORD) {
  console.error("Set SESSION_SECRET, PAYSTACK_SECRET_KEY, and ADMIN_PASSWORD in .env before starting.");
  process.exit(1);
}

db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS songs (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, price_kobo INTEGER NOT NULL,
 release_date TEXT, preview_path TEXT, full_path TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, song_id INTEGER NOT NULL, email TEXT NOT NULL,
 reference TEXT UNIQUE NOT NULL, amount_kobo INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(song_id) REFERENCES songs(id)
);
CREATE TABLE IF NOT EXISTS purchases (
 id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER UNIQUE NOT NULL, song_id INTEGER NOT NULL,
 email TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(order_id) REFERENCES orders(id), FOREIGN KEY(song_id) REFERENCES songs(id)
);`);

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb", verify: (req, res, buf) => { req.rawBody = buf; } }));
app.use(express.urlencoded({ extended: false, limit: "100kb" }));
app.use(session({
  name: "firstto.sid", secret: process.env.SESSION_SECRET, resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
    filename: (_req, file, cb) => cb(null, crypto.randomUUID() + path.extname(file.originalname).toLowerCase())
  }),
  limits: { fileSize: 50 * 1024 * 1024, files: 2 },
  fileFilter: (_req, file, cb) => {
    const ok = file.mimetype.startsWith("audio/") && /\.(mp3|wav|m4a|ogg|aac|flac)$/i.test(file.originalname);
    cb(ok ? null : new Error("Upload audio files only (MP3, WAV, M4A, OGG, AAC, FLAC)."), ok);
  }
});

function adminOnly(req, res, next) {
  if (req.session?.isAdmin) return next();
  return res.status(401).json({ error: "Artist sign-in required." });
}
function paystackHeaders() {
  return { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`, "Content-Type": "application/json" };
}
async function verifyPaystack(reference) {
  const r = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, { headers: paystackHeaders() });
  const data = await r.json();
  if (!r.ok || !data.status) throw new Error("Could not verify payment with provider.");
  return data.data;
}
function fulfilIfValid(tx) {
  if (!tx || tx.status !== "success" || tx.currency !== "NGN") return false;
  const order = db.prepare("SELECT * FROM orders WHERE reference = ?").get(tx.reference);
  if (!order || Number(tx.amount) !== Number(order.amount_kobo)) return false;
  const markPaid = db.transaction(() => {
    db.prepare("UPDATE orders SET status='paid' WHERE id=? AND status!='paid'").run(order.id);
    db.prepare("INSERT OR IGNORE INTO purchases(order_id,song_id,email) VALUES(?,?,?)").run(order.id, order.song_id, order.email);
  });
  markPaid();
  return true;
}

// Public song catalogue never exposes private full-file paths.
app.get("/api/songs", (_req, res) => {
  const rows = db.prepare("SELECT id,title,price_kobo,release_date,preview_path FROM songs ORDER BY created_at DESC").all();
  res.json(rows.map(s => ({ ...s, price_ngn: s.price_kobo / 100, preview_url: s.preview_path ? `/api/previews/${s.id}` : null })));
});

app.get("/api/previews/:id", (req, res) => {
  const song = db.prepare("SELECT preview_path FROM songs WHERE id=?").get(Number(req.params.id));
  if (!song?.preview_path) return res.sendStatus(404);
  const file = path.resolve(UPLOAD_DIR, song.preview_path);
  if (!file.startsWith(UPLOAD_DIR + path.sep) || !fs.existsSync(file)) return res.sendStatus(404);
  res.setHeader("Cache-Control", "public, max-age=300");
  res.type(path.extname(file));
  res.sendFile(file);
});

// Admin authentication. Use a long unique password; add rate limiting before public deployment.
app.post("/api/admin/login", (req, res) => {
  if (typeof req.body.password !== "string" || !crypto.timingSafeEqual(
    Buffer.from(crypto.createHash("sha256").update(req.body.password).digest("hex")),
    Buffer.from(crypto.createHash("sha256").update(process.env.ADMIN_PASSWORD).digest("hex"))
  )) return res.status(401).json({ error: "Invalid password." });
  req.session.isAdmin = true;
  res.json({ ok: true });
});
app.post("/api/admin/logout", adminOnly, (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/admin/me", (req, res) => res.json({ isAdmin: !!req.session?.isAdmin }));

app.post("/api/admin/songs", adminOnly, upload.fields([{ name: "preview", maxCount: 1 }, { name: "full", maxCount: 1 }]), (req, res) => {
  const title = String(req.body.title || "").trim();
  const priceNgn = Number(req.body.price_ngn);
  const releaseDate = String(req.body.release_date || "").trim() || null;
  const preview = req.files?.preview?.[0];
  const full = req.files?.full?.[0];
  if (!title || title.length > 120 || !Number.isSafeInteger(priceNgn) || priceNgn < 100 || !full) {
    if (preview) fs.rmSync(preview.path, { force: true });
    if (full) fs.rmSync(full.path, { force: true });
    return res.status(400).json({ error: "Title, price (at least ₦100), and full audio file are required." });
  }
  const result = db.prepare("INSERT INTO songs(title,price_kobo,release_date,preview_path,full_path) VALUES(?,?,?,?,?)")
    .run(title, priceNgn * 100, releaseDate, preview?.filename || null, full.filename);
  res.status(201).json({ id: result.lastInsertRowid, ok: true });
});

// Order amount and song ID are looked up on the server; clients cannot choose a price.
app.post("/api/checkout", async (req, res) => {
  const songId = Number(req.body.song_id);
  const email = String(req.body.email || "").trim().toLowerCase();
  if (!Number.isInteger(songId) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    return res.status(400).json({ error: "Enter a valid email and song." });
  }
  const song = db.prepare("SELECT id,title,price_kobo FROM songs WHERE id=?").get(songId);
  if (!song) return res.status(404).json({ error: "Song not found." });
  const reference = `ft${Date.now()}${crypto.randomBytes(6).toString("hex")}`;
  db.prepare("INSERT INTO orders(song_id,email,reference,amount_kobo,status) VALUES(?,?,?,?, 'pending')")
    .run(song.id, email, reference, song.price_kobo);
  const response = await fetch("https://api.paystack.co/transaction/initialize", {
    method: "POST", headers: paystackHeaders(),
    body: JSON.stringify({
      email, amount: String(song.price_kobo), currency: "NGN", reference,
      channels: ["bank_transfer", "card", "bank"],
      callback_url: `${process.env.PUBLIC_BASE_URL}/payment-return`,
      metadata: { song_id: song.id, song_title: song.title }
    })
  });
  const payload = await response.json();
  if (!response.ok || !payload.status) {
    db.prepare("UPDATE orders SET status='init_failed' WHERE reference=?").run(reference);
    return res.status(502).json({ error: "Could not start checkout. Try again." });
  }
  res.json({ authorization_url: payload.data.authorization_url, reference });
});

// Callback is only a prompt to verify. A redirect alone is never proof of payment.
app.get("/payment-return", async (req, res) => {
  const reference = String(req.query.reference || "");
  if (!reference) return res.status(400).send("Missing payment reference.");
  try {
    const tx = await verifyPaystack(reference);
    const paid = fulfilIfValid(tx);
    res.status(paid ? 200 : 202).send(paid
      ? "Payment verified. Return to FIRST TO and use the same email to request your secure download."
      : "Payment is not confirmed yet. Please wait a moment and refresh this page.");
  } catch {
    res.status(502).send("We could not verify this payment right now. Do not pay again; contact support with your reference.");
  }
});

// Paystack signs the raw request body with HMAC SHA512. Verify before processing.
app.post("/api/paystack/webhook", (req, res) => {
  const signature = req.get("x-paystack-signature") || "";
  const expected = crypto.createHmac("sha512", process.env.PAYSTACK_SECRET_KEY).update(req.rawBody || Buffer.from("")).digest("hex");
  const a = Buffer.from(signature, "utf8"), b = Buffer.from(expected, "utf8");
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.sendStatus(401);
  if (req.body?.event === "charge.success" && req.body?.data?.reference) {
    // A valid signature authenticates the event; verify with Paystack and match amount/currency/order too.
    verifyPaystack(String(req.body.data.reference))
      .then(fulfilIfValid)
      .catch(err => console.error("Webhook verification failed:", err.message));
  }
  return res.sendStatus(200);
});

// Request a download email/link after purchase; prototype sends no email.
// In production, add email OTP or account login before issuing a short-lived download URL.
app.post("/api/library/lookup", (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email." });
  const items = db.prepare(`SELECT p.id AS purchase_id,s.id AS song_id,s.title,p.created_at
    FROM purchases p JOIN songs s ON s.id=p.song_id WHERE lower(p.email)=? ORDER BY p.created_at DESC`).all(email);
  // Do not expose direct downloads based on email alone; require a verified magic link in production.
  res.json({ purchases: items, message: "Purchase list only. Add verified email sign-in before enabling download links." });
});

app.get("/api/download/:purchaseId", (_req, res) => {
  return res.status(501).json({ error: "Downloads stay locked until email/account verification and short-lived signed links are configured." });
});

app.use((err, req, res, next) => {
  console.error(err.message);
  if (res.headersSent) return next(err);
  res.status(400).json({ error: err.message || "Request failed." });
});
app.listen(PORT, () => console.log(`FIRST TO server listening on http://localhost:${PORT}`));
